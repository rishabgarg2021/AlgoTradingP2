import time
from datetime import datetime

import pytz

from fmclient.data.orm.order import Order, OrderType, OrderSide
from . import constants as cons

COMMENT = "#"
NEWLINE = "\n"


def time_milli():
    return int(round(time.time() * 1000))


def string_to_date(date_string, format, timezone):
    date = datetime.strptime(date_string, format)
    return date.replace(tzinfo=timezone)


def to_local(date, local_timezone):
    timezone = pytz.timezone(local_timezone)
    return date.astimezone(timezone)


def json_to_order(content):
    if content["side"].lower() == "buy":
        side = OrderSide.BUY
    else:
        side = OrderSide.SELL
    if content["type"].lower() == "limit":
        order_type = OrderType.LIMIT
    elif content["type"].lower() == "cancel":
        order_type = OrderType.CANCEL
    else:
        order_type = None

    order = Order(content["price"], content["units"], order_type, side, content["marketId"])
    order.mine = content["mine"]
    order.id = content["id"]
    order.original = content["original"]
    order.date = to_local(string_to_date(content["createdDate"], cons.DATE_FORMAT, pytz.utc), cons.LOCAL_TIMEZONE)

    return order


def clean_line(line):
    line = line.strip()
    if len(line):
        if line[0] == COMMENT:
            return ""
        if line[-1] == NEWLINE:
            return line[:-1]
    return line


def get_index(l: list, item):
    try:
        return l.index(item)
    except ValueError:
        return None


def clean_string(string):
    keepcharacters = ('-', '.', '_', '@')
    return "".join(c for c in string if c.isalnum() or c in keepcharacters).strip()


def str_shorten(string, length=10):
    """Returns a truncated version of string. Default length is 10"""
    return string if len(string) <= length else string[:length]
