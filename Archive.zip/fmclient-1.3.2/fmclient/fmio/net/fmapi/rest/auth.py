"""
This class should contain the initial authorisation that could be passed around for all future communications
"""

import aiohttp
import asyncio

from fmclient.utils import constants
from fmclient.utils.singleton import Singleton


class Auth(object, metaclass=Singleton):

    def __init__(self, account=None, email=None, password=None):

        assert account is not None and account is not '', "FMAuth: Account cannot be None or empty"
        assert email is not None and email is not '', "FMAuth: Email cannot be None or empty"
        assert password is not None and password is not '', "FMAuth: Password cannot be None or empty"

        self._email = email
        self._account = account
        self._password = password
        self._login = account + "|" + email
        self._basic_auth = aiohttp.BasicAuth(self._login, self._password)
        self._bearer_auth = ''

        # New bearer auth method requires sending data as POST and getting Bearer token for future auth in header
        async def get_auth_token():
            auth_data = {"username": self._login, "password": self._password}
            auth_url = constants.API_ROOT + "/tokens"
            async with aiohttp.ClientSession() as sess:
                async with sess.request("POST", auth_url, json=auth_data) as resp:
                    if "Authorization" in resp.headers.keys():
                        self._bearer_auth = resp.headers["Authorization"]
                    else:
                        self._basic_auth = None

        asyncio.get_event_loop().run_until_complete(asyncio.gather(get_auth_token()))

    @property
    def auth(self):
        return self._basic_auth

    @property
    def bearer_auth(self):
        return self._bearer_auth
