"""
Market module consisting of Market entity from API and related classes and methods
"""


class Market(object):
    """
    A Market class that represents a market in a marketplace.
    Objects of this class can be used for either representing a market in marketplace or
    for storing market data for holdings only (which normally only contain market's item name and units)
    """

    def __init__(self, name=None, item=None, units=None):
        self._id = None
        self._name = name  # Take from API
        self._item = item  # Take from API
        self._units = units  # Take from API
        self._description = None  # Take from API
        self._publicMarket = False  # Take bool from API
        self._minimumPrice = 0  # Take from API
        self._maximumPrice = 0  # Take from API
        self._priceTick = 25  # Take from API, however minimum in FM is usually 25

    @property
    def item(self):
        return self._item

    @item.setter
    def item(self, value: str):
        self._item = str(value)

    @property
    def units(self):
        return self._units

    @units.setter
    def units(self, value: int):
        assert value >= 0
        self._units = value

    def __str__(self) -> str:
        return ':'.join([str(self.item), str(self.units)])

    def __repr__(self) -> str:
        return self.__str__()

